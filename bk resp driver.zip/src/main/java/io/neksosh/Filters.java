package io.neksosh;

import spark.Request;
import spark.Response;

public class Filters {

    public static void setQueryLocale(Request request, Response response) {
        String locale = request.queryParams("locale");
        if (locale != null) {
            request.session().attribute("locale", locale);
            response.redirect(request.pathInfo());
        }
    }
}
