package io.neksosh.handler;

import spark.Route;
import io.neksosh.Template;
import static io.neksosh.ModelEntry.entry;
import static io.neksosh.Template.render;

public class DashboardHandler {

    public Route view() {
        return (req, resp) -> {
            int numDriversAprv = 648;
            int numDriversPend = 37;
            int numDriversReg = 751;
            return render(req, Template.DASHBOARD,
                entry("title", "Index"),
                entry("name", "Eduardo"),
                entry("numDriversAprv", numDriversAprv),
                entry("numDriversPend", numDriversPend),
                entry("numDriversReg", numDriversReg)
            );
        };
    }
}
