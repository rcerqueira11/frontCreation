package io.neksosh.handler;

import io.neksosh.Template;
import spark.Route;

import static io.neksosh.ModelEntry.entry;
import static io.neksosh.Template.render;

public class LoginHandler {

    public static Route login() {
        return (req, resp) -> render(req, Template.LOGIN,
                entry("title", "Nekso Login"),
                entry("error", false),
                entry("dashboardRoute",Template.DASHBOARD));
    }
}