package io.neksosh.handler;

import io.neksosh.Template;
import io.neksosh.driver.contract.*;
import io.neksosh.driver.contract.DriverServicePrivateGrpc.DriverServicePrivateBlockingStub;
import spark.Route;

import java.util.Arrays;
import java.util.Optional;

import static io.neksosh.ModelEntry.entry;
import static io.neksosh.Template.render;

public class DriverHandler {

    private final DriverServicePrivateBlockingStub driverService;

    public DriverHandler(DriverServicePrivateBlockingStub driverService) {
        this.driverService = driverService;
    }

    // TODO: Remove when security be implemented
    private static final DriverAdminViewList driverList = DriverAdminViewList.newBuilder()
            .addAllDrivers(Arrays.asList(
                    DriverAdminView.newBuilder()
                            .setId("1")
                            .setName("Eduardo Caceres")
                            .setCity("Maracaibo")
                            .setCountry("Venezuela")
                            .setDriverReviewStatus("Pending for Documentation")
                            .build(),
                    DriverAdminView.newBuilder()
                            .setId("2")
                            .setName("Alejandro Nava")
                            .setCity("Maracaibo")
                            .setCountry("Venezuela")
                            .setDriverReviewStatus("Pending for Documentation")
                            .build(),
                    DriverAdminView.newBuilder()
                            .setId("3")
                            .setName("Ricardo Valbuena")
                            .setCity("Maracaibo")
                            .setCountry("Venezuela")
                            .setDriverReviewStatus("Pending for Documentation")
                            .build(),
                    DriverAdminView.newBuilder()
                            .setId("4")
                            .setName("Ricardo Cerqueira")
                            .setCity("Caracas")
                            .setCountry("Venezuela")
                            .setDriverReviewStatus("Pending for Documentation")
                            .build(),
                    DriverAdminView.newBuilder()
                            .setId("4")
                            .setName("Jhonny Muñoz")
                            .setCity("Caracas")
                            .setCountry("Venezuela")
                            .setDriverReviewStatus("Pending for Submission")
                            .build()
            ))
            .build();

    public Route viewAll() {
        return (req, resp) -> {
            int limit = Optional.ofNullable(req.queryParams("limit")).map(Integer::valueOf).orElse(20);
            String lastKey = Optional.ofNullable(req.queryParams("lastKey")).orElse("");

//            DriverAdminViewList driverList = driverService.findByTaxiline(DriversByTaxilineRequest.newBuilder()
//                    .setTaxilineId("ea4154f4-4d4c-432c-bbd1-321c1aa57914") // Get from token
//                    .setPagination(BasicPagination.newBuilder()
//                            .setLimit(limit)
//                            .setLastEvalKey(lastKey)
//                            .build())
//                    .build());

            return render(req, Template.DRIVERS,
                    entry("title", "Drivers"),
                    entry("section", "drivers"),
                    entry("drivers", driverList.getDriversList()));
        };
    }

    public Route view() {
        return (req, resp) -> {
            String driverId = req.params("driverId");
            return render(req, Template.DRIVERS_VIEW,
                    entry("title", "Driver View"),
                    entry("section", "drivers"),
                    entry("driver", driverService.get(User.newBuilder().setId(driverId).build())));
        };
    }

    public Route create() {
        return (req, resp) -> render(req, Template.DRIVERS_CREATE,
                entry("title", "Driver registration"),
                entry("section", "drivers"));
    }

    public Route register() {
        return (req, resp) -> {
            String driverId = driverService.register(RegistrationRequest.newBuilder()
                    .setName(req.queryParams("fullName"))
                    .setEmail(req.queryParams("email"))
                    .setCountryIsoCode(req.queryParams("countryCode"))
                    .setPhone(req.queryParams("phone"))
                    .setWorkingCity(req.queryParams("workingCity"))
                    .setVehicle(VehicleDTO.newBuilder()
                            .setCar(CarDTO.newBuilder()
                                    .setMaker(req.queryParams("carMaker"))
                                    .setModel(req.queryParams("carModel"))
                                    .build())
                            .setYear(Integer.parseInt(req.queryParams("carYear")))
                            .setColor(req.queryParams("carColor"))
                            .setLicensePlate(req.queryParams("carLicensePlate"))
                            .setTaxiLine(TaxiLineDTO.newBuilder()
                                    .setId(req.queryParams("taxiLineId"))
                                    .build())
                            .build())
                    .build())
                    .getId();
            resp.redirect("/drivers/" + driverId);
            return resp;
        };
    }
}