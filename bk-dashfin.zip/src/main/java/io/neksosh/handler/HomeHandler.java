package io.neksosh.handler;

import io.neksosh.Template;
import spark.Route;

import static io.neksosh.ModelEntry.entry;
import static io.neksosh.Template.render;

public class HomeHandler {

    public Route view() {
        return (req, resp) -> render(req, Template.HOME,
                entry("title", "Home"),
                entry("section", "home"));
    }

}