
package io.neksosh.handler;

import io.neksosh.Template;
import spark.Route;

import static io.neksosh.ModelEntry.entry;
import static io.neksosh.Template.render;

public class RecoverPasswordHandler {
    public static Route recoverPass() {

        return (request, response) -> render(request, Template.RECOVER_PASSWORD,
                entry("title", "Nekso Recover Password"),
                entry("error", false),
                entry("error_message", "There is an error with this email."));
    }
}


