package io.neksosh;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.neksosh.driver.contract.DriverServicePrivateGrpc;
import io.neksosh.handler.DriverHandler;
import io.neksosh.handler.HomeHandler;
import io.neksosh.handler.RecoverPasswordHandler;
import io.neksosh.handler.LoginHandler;
import io.neksosh.handler.DashboardHandler;
import spark.Redirect;

import java.util.Optional;

import static spark.Spark.*;
import static spark.debug.DebugScreen.enableDebugScreen;

public class Main {

    public static void main(String[] args) {
        int webAppPort = 8080;
        port(webAppPort);
        staticFiles.location("/public");

        String host = Optional.ofNullable(System.getenv("GRPC_API_HOST")).orElse("localhost");
        int port = Optional.ofNullable(System.getenv("GRPC_API_PORT")).map(Integer::valueOf).orElse(5001);

        ManagedChannel channel = ManagedChannelBuilder
                .forAddress(host, port)
                .usePlaintext(true)
                .build();

        DriverHandler driverHandler = new DriverHandler(DriverServicePrivateGrpc.newBlockingStub(channel));
        HomeHandler homeHandler = new HomeHandler();
        DashboardHandler dashboardHandler = new DashboardHandler();

        before("*", Filters::setQueryLocale);

        get("/", homeHandler.view());
        get("/login", LoginHandler.login());
        get("/dashboard", dashboardHandler.view());
        get("/recover-password", RecoverPasswordHandler.recoverPass());
        get("/login", LoginHandler.login());
        path("/drivers", () -> {
                get("", driverHandler.viewAll());
                get("/:driverId/view", driverHandler.view());
                get("/create", driverHandler.create());
                post("/register", driverHandler.register());
        });
        redirect.post("/login", "/dashboard", Redirect.Status.SEE_OTHER);

        enableDebugScreen(); // only dev
        System.out.println("\nServer Running on port " + webAppPort + "\n");
    }

}