package io.neksosh;

import spark.ModelAndView;
import spark.Request;
import spark.template.velocity.VelocityTemplateEngine;

import java.util.*;

public interface Template {

    VelocityTemplateEngine instance = null;

    String HOME = "/templates/home.vm";
    String LOGIN = "/templates/login.vm";
    String RECOVER_PASSWORD = "/templates/recover_password.vm";
    String DASHBOARD = "/templates/dashboard.vm";
    
    String DRIVERS = "/templates/drivers.vm";
    String DRIVERS_VIEW = "/templates/drivers_view.vm";
    String DRIVERS_CREATE = "/templates/drivers_create.vm";

    static VelocityTemplateEngine getInstance() {
        return Optional.ofNullable(instance).orElse(newInstance());
    }

    static VelocityTemplateEngine newInstance() {
        return new VelocityTemplateEngine();
    }

    static String render(Request request, String templatePath, ModelEntry... entries) {
        Locale locale = request.session().attribute("locale") != null ? new Locale(templatePath) : Locale.ENGLISH;

        HashMap<String, Object> model = new HashMap<String, Object>() {{
            put("texts", ResourceBundle.getBundle("texts", locale));
        }};
        for (ModelEntry entry: entries) model.put(entry.getKey(), entry.getValue());

        return getInstance().render(new ModelAndView(model, templatePath));
    }
}